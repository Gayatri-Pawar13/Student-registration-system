// Wait for the DOM to be loaded
document.addEventListener("DOMContentLoaded", () => {
    const studentForm = document.getElementById("studentForm");
    const studentsTable = document.getElementById("studentsTable").getElementsByTagName("tbody")[0];

    // Load stored data from local storage
    loadStudents();

    // Handle form submission
    studentForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const studentName = document.getElementById("studentName").value;
        const studentId = document.getElementById("studentId").value;
        const email = document.getElementById("email").value;
        const contactNo = document.getElementById("contactNo").value;

        // Validation
        if (!studentName || !studentId || !email || !contactNo) {
            alert("Please fill in all fields.");
            return;
        }

        if (!/^\d+$/.test(studentId) || !/^\d{10}$/.test(contactNo)) {
            alert("Student ID must be a number and Contact No must be a 10-digit number.");
            return;
        }

        if (!validateEmail(email)) {
            alert("Please enter a valid email address.");
            return;
        }

        // Create new student record
        const student = {
            id: studentId,
            name: studentName,
            email: email,
            contactNo: contactNo
        };

        // Add student to table and local storage
        addStudentToTable(student);
        saveStudentToLocalStorage(student);

        // Reset the form
        studentForm.reset();
    });

    // Load and display students from local storage
    function loadStudents() {
        const students = JSON.parse(localStorage.getItem("students")) || [];
        students.forEach(student => addStudentToTable(student));
    }

    // Add student to the table
    function addStudentToTable(student) {
        const row = studentsTable.insertRow();
        row.dataset.id = student.id;

        row.innerHTML = `
            <td>${student.name}</td>
            <td>${student.id}</td>
            <td>${student.email}</td>
            <td>${student.contactNo}</td>
            <td>
                <button class="edit" onclick="editStudent('${student.id}')">Edit</button>
                <button class="delete" onclick="deleteStudent('${student.id}')">Delete</button>
            </td>
        `;
    }

    // Save student data to local storage
    function saveStudentToLocalStorage(student) {
        const students = JSON.parse(localStorage.getItem("students")) || [];
        students.push(student);
        localStorage.setItem("students", JSON.stringify(students));
    }

    // Edit student record
    window.editStudent = function (studentId) {
        const students = JSON.parse(localStorage.getItem("students")) || [];
        const student = students.find(student => student.id === studentId);
        
        if (student) {
            document.getElementById("studentName").value = student.name;
            document.getElementById("studentId").value = student.id;
            document.getElementById("email").value = student.email;
            document.getElementById("contactNo").value = student.contactNo;

            // Remove the student from the table and local storage before updating
            deleteStudent(studentId, true);
        }
    };

    // Delete student record
    window.deleteStudent = function (studentId, isEdit = false) {
        const row = document.querySelector(`[data-id="${studentId}"]`);
        if (row) {
            row.remove();
        }

        let students = JSON.parse(localStorage.getItem("students")) || [];
        students = students.filter(student => student.id !== studentId);
        localStorage.setItem("students", JSON.stringify(students));

        if (!isEdit) {
            alert("Student record deleted successfully!");
        }
    };

    // Email validation
    function validateEmail(email) {
        const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        return regex.test(email);
    }
});
